import IconSocialMediaInstagram from './IconSocialMediaInstagram';

export const Icon = {
  component: IconSocialMediaInstagram,
  props: {},
  group: 'icons',
};

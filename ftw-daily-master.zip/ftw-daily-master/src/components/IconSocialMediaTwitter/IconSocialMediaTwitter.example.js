import IconSocialMediaTwitter from './IconSocialMediaTwitter';

export const Icon = {
  component: IconSocialMediaTwitter,
  props: {},
  group: 'icons',
};

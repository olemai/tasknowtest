# Environment configuration variables

Documentation moved to the Flex Docs site:

https://www.sharetribe.com/docs/references/ftw-env/

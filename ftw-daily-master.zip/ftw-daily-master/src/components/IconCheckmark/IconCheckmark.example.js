import IconCheckmark from './IconCheckmark';

export const Icon = {
  component: IconCheckmark,
  props: {},
  group: 'icons',
};

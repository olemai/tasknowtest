# Search filters

Documentation moved to the Flex Docs site:

https://www.sharetribe.com/docs/guides/how-to-change-search-filters-in-ftw/

/* eslint-disable no-console */
import NamedLink from './NamedLink';

export const NamedLinkToSearchPage = {
  component: NamedLink,
  props: {
    name: 'SearchPage',
    children: 'SearchPage',
  },
  group: 'navigation',
};

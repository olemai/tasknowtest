# Routing

Documentation moved to the Flex Docs site:

https://www.sharetribe.com/docs/background/ftw-routing/

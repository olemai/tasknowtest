import IconEdit from './IconEdit';

export const Icon = {
  component: IconEdit,
  props: {},
  group: 'icons',
};

# Improving page rendering performance

Documentation moved to the Flex Docs site:

https://www.sharetribe.com/docs/guides/how-to-improve-performance/
